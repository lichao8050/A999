# _*_ coding: utf-8 _*_
#@Time    : 2021/8/25 10:04
#@Author  : LiChao
#@FileName: test_negotiate_project.py
from pageobject.negotiate_project import NegoTiateProject


class NegotiateProject(NegoTiateProject):
    '''洽谈项目'''

    def test_negotiate_project(self,username, password):
        pass