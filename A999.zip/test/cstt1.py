# _*_ coding: utf-8 _*_
# @Time     : 2022/1/19 18:30
# @Author   : Mr_Li
# @FileName : cstt1.py
from telnetlib import EC


