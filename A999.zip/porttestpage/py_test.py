# _*_ coding: utf-8 _*_
# @Time     : 2022/4/20 9:37
# @Author   : Mr_Li
# @FileName : py_test.py

import requests
import json

s = requests.session()
url = "http://kbs.matrixdesign.cn/api/pmtapi/base_Account/login?username=heqiangming&password=abc123456"
headers = {"Content-Type": "application/json;charset=UTF-8"}
r = s.post(url, headers)
print(r.status_code)
print(r.headers["Set-Cookie"])
# r.encoding = "UTF-8"
# print(r.json())
# url1 = "http://kbs.matrixdesign.cn/api/authapi/bsProInfo/getPagedList"
# data = {
#     "skipCount": 1,
#     "maxResultCount": 10,
#     "module": 1,
#     "proName": "测试2204201112"
# }
#
# r2 = s.post(url=url1, headers=headers, json=data)
# print(r2.text)
url2 = "http://kbs.matrixdesign.cn/api/authapi/bsCustomer/save"
data2 = {
    "customerName": "栋来西往12",
    "ownerName": "郑鸿晖",
    "owner": "16073917709738137",
    "customerArea": "华南",
    "customerProvince": "440000",
    "customerCity": "440200",
    "adminArea": "华南地区",
    "customerType": "1280319512448733185",
    "customerGrade": "customer_grade_d",
    "bsStakeholderList": [
        {
            "entityStatus": 0,
            "index": 0,
            "name": "测试张三丰2",
            "phone": "16548754512",
            "address": "测试阿萨达11",
            "type": "1280322115026948097",
            "job": "1测试121"
        }
    ],
    "groupName": "测试港深集团013"
}
r3 = s.post(url=url2, headers=headers, json=data2)
print(r3.text)
